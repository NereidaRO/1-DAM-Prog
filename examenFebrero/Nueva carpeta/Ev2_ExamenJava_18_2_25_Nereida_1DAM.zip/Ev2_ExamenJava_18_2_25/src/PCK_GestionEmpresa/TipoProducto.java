package PCK_GestionEmpresa;

public enum TipoProducto {
	MOTOR, ROPA
}
