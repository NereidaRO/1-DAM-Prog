/**
 * 
 */
package PCK_GestionEmpresa;

/**
 * @author Nereida Rodríguez Orenes 1ºDAM
 * @since 18/02/2025
 */

public interface IGestion {
	public boolean crearEmpresa();
	public boolean crearArticulo();
	public boolean crearFactura();
	public void mostrarFacturas();
}
